## 切莫得意忘形,谦卑啊~~~~

## 逻辑层 

#### (先看懂语法,再看功能)  学一个知识点=>是什么,为什么要用,如何用

#### 面试时有个 2+2+1原理,问你50个题,2个题你得超过他的期待,2个题中规中矩,1个题能说出点东西就行  回答题时:得说到点上

#### 状态码解释

400 请求出错(服务器无法理解)	401未被授权	403禁止访问	404 访问数据资源无法找到	 405资源被禁止	408请求超时	500服务器错误	 502错误网关  305 使用代理(比如外网使用vpn)

状态码：1xx，指示信息，表示请求已经接受了，继续处理

　　　　2xx，标识请求已经成功处理掉了

　　　　3xx，请求重定向

　　　　4xx，客户端错误了，请求的时候有语法错误，或者说请求无法实现

　　　　5xx，服务器端错误，服务器无法完成合法的请求

- 200 OK - [GET]：服务器成功返回用户请求的数据，该操作是幂等的（Idempotent）。
- 201 CREATED - [POST/PUT/PATCH]：用户新建或修改数据成功。
- 202 Accepted - [*]：表示一个请求已经进入后台排队（异步任务）
- 204 NO CONTENT - [DELETE]：用户删除数据成功。
- 400 INVALID REQUEST - [POST/PUT/PATCH]：用户发出的请求有错误，服务器没有进行新建或修改数据的操作，该操作是幂等的。
- 401 Unauthorized - [*]：表示用户没有权限（令牌、用户名、密码错误）。
- 403 Forbidden - [*] 表示用户得到授权（与401错误相对），但是访问是被禁止的。
- 404 NOT FOUND - [*]：用户发出的请求针对的是不存在的记录，服务器没有进行操作，该操作是幂等的。
- 406 Not Acceptable - [GET]：用户请求的格式不可得（比如用户请求JSON格式，但是只有XML格式）。
- 410 Gone -[GET]：用户请求的资源被永久删除，且不会再得到的。
- 422 Unprocesable entity - [POST/PUT/PATCH] 当创建一个对象时，发生一个验证错误。
- 500 INTERNAL SERVER ERROR - [*]：服务器发生错误，用户将无法判断发出的请求是否成功。

#### 浮点数的精确度

0.1  0.2  0.2-0.1==0.1  0.1+0.2!=0.3

浮点数解决:一种是保留两位小数 toFixed(2) 

二种吧需要计算的数乘以10 的n次幂,换算成计算能识别的整数,再除以10 的n次幂,得到最终结果

function computer(s,digit){

​	let m=Math.pow(10,digit)

​	return parseInt(s*m)/m

}

computer(0.1+0.2,1)

#### let var const三者的区别

①let 同一变量只能声明一次,不存在声明提升,es6为块级作用域

②var能多次声明同一变量,后面声明覆盖前面声明的值,存在声明提升,

③const 常在块级作用域中使用,定义的常量是不可变的,必须初始赋值(初始化)

#### es6 新特性

①块级作用域 let ② 解构 解构引用类型数据 ③模板字符串 `${}`拼接参数 ④扩展运算符 ...  浅克隆数组 ⑤箭头函数 (使this一直指向被调用的环境)
⑥symbol 数据类型 (常用作唯一值使用,比如游戏 id)
⑦class类(react中类组件就是继承react.component 的类函数)  

 class Liukai{

​	constructor()  

​	study(){ 

​		console.log('刘凯每天都在好好学习')

​	} 

​	girlFriend(){

​		console.log('my girl friend name is CaoLi')

​	}

}

var beautifulBoy=new Liukai();  beautifulBoy.girlFriend()//'my girl friend name is CaoLi'

#### 懒加载及预加载

**懒加载**  (主要是作为服务器前端的有优化,减少请求次数)

实现有三种: 

①纯粹懒加载 ,使用setTimeout,setInterval延迟加载    

②条件加载,符合某些设定调价,或触发了某些事件才开始异步加载

③可视区加载,滚动事件(onscroll)  随滚动条的距离来加载资源, 一般距离用户看到资源前多少距离就开始加载,从而保证用户刚好看到就会加载出来

eg:东哥说的vue中的组件懒加载(在router文件中不引入 组件,直接在组件配置信息中的component属性 **使用箭头函数** component: () => import( '../views/xxx.vue')临时引入)  **彻底懒加载**: 如果用户不访问,就不会加载其他组件内容 vue自带 (在vue.config.js文件中设置 禁止其他组件异步延迟加载{删除提前获取config.plugins.delete("prefetch")})

**预加载**  (牺牲前端性能换取用户的更好体验) https://www.cnblogs.com/ranyonsue/p/11778306.html     

 css和js都可以单独 实现 ,css是利用**位置设置**在当前页面不可视区域来提前加载 ,而js方法很多 ,一般是在做**异步请求**利用  **new Image()**方法 的 **src 属性**来 提前加载(比如在页面中直接执行document.images方法或者将该方法使用addLoadEvent()来添加到页面加载事件中,再使用window.onLoad()方法异步延迟执行),  还有  ajax请求中也可以实现,一般是创建link ,script 两个元素的对应属性(href,src)请求js ,css 文件 ,再用new Image().src去请求image资源,直接预加载 图片/ js /css资源  (**一般用于广告弹窗**)

**ajax实例**

`window.onload = function() {  
    setTimeout(function() {  
        // XHR to request a JS and a CSS  
        var xhr = new XMLHttpRequest();  
        xhr.open('GET', 'http://geekjc.com/preload.js');  
        xhr.send('');  
        xhr = new XMLHttpRequest();  
        xhr.open('GET', 'http://geekjc.com/preload.css');  
        xhr.send('');  
        // preload image  
        new Image().src = "http://geekjc.com/preload.png";  
    }, 1000);  //1000为了防止脚本挂起
};`

**挂起进程的含义**` 挂起进程在操作系统中可以定义为暂时被淘汰出内存的进程,机器的资源是有限的,在资源不足的情况下,操作系统对在内存中的程序进行合理的安排,其中有的进程被暂时调离出内存,当条件允许的时候,会被操作系统再次调回内存,重新进入等待被执行的状态即就绪态,系统在超过一定的时间没有任何动作。” `

### -------说服点③----

#### ---**浏览器缓存**

缓存数据格式为JSON , json转化为 js 是 json.parse()  而 js 转化为 json 是 JSON .stringify()

**cookie** 最多储存4 k   键值对形式储存 ,用户信息,识别用户, 通过 path(路径)属性 在页面之间传递共享,通过保存用户uid,服务器 会话sid等,记录用户登录状态, **可以用作保存信息的储存时长** --->  document.cookie="键值对, **expires**="+new Date().getFullYear() +5 (从今年开始存五年)  获取:document.cookie

**webStorage**: (存储结合vuex)

​	sessionStorage最多储存1 m ,关闭当前页面就会消失,适用于会话存储

​	localStorage 永久本地储存,除非clear() 或 removeItem()  (储存内存随设备不同大小不一,可以查到,2.5-10m之间),浏览器隐私模式不可读取,储存内容过多会占内存,会使页面卡顿

​	userData / indexedDB

服务器端储存  **session**

**session 的工作机制**

session是服务器端分配的一块缓存,浏览器在cookie 中有个sessionid字段,在浏览器与服务器交互中,可以通过sessionid 与seeion 进行验证,从而将cookie中缓存数据提取到服务器端保存,而保存在服务器端安全性更高



#### 真假值

**假值** **false / undefined / 0 /null /  '' / NaN**

而 空数组 **[ ]**  在条件判断中隐式**转换为 true(因为 [ ] 是一个对象)**  

但 在 与布尔值的比较中发生类型转换: **转换为 0**

## 

### -------说服点②----

#### 跨域 : 前端浏览器 jsonp (先搜文档看,看不懂再看东哥)后台服务器 cors同源策略

**jsonp**(json with padding json数据的填充) 原理是 **浏览器端动态创建script标签,借助script的src属性发送请求(url由请求地址+请求参数+callback函数名组成),服务器端接收请求,响应填充后的js语句,浏览器端执行返回来的js语句（前后端约定好）** 

**vue** 里设置 jsonp 是在前端页面定义一个  window  下的全局函数(一般都为全局函数, 将该 **函数名** 以 **callback参数形式** 和数据参数一起传递给后端, 后端接收后响应 **一串与该函数对应 的数据**, 然后在前端页面执行该返回的js数据  (有问题, vue中是以 promise 的 回调形式 来做的)

**注意:**这个返回的数据是经过填充后的js语句数据{这个数据根据前端的执行不同可以设置是个函数也可以是纯js语句}) ,然后在前端页面执行该返回的js数据 (**函数名不同**和**函数执行内容不同**以及动态创建script元素和执行完后的删除添加的script元素从而不会堆积元素这些都可以在前端设置,最后在实际工作中直接通过 jQuery里的简化 后的dataType:"jsonp" 属性直接设置该请求为jsonp请求,简化前端代码)

**后端 :** 手写过滤器，手写拦截器，jsonp，注解方式，配置nginx反向代理 

#### 数组API

**不改变原数组的API**  :  **concat(拼接)  join(转换为字符串)  slice(start ,end)**

其余都会改变原数组 :splice(start,count,xx...)  	toString() 	pop() 	push()	shift()	unshift()(开头添加)	reverse()  sort(){又分a-b小到大,b-a大到小}(填坑+分治法的快排原理)



#### 6种基本数据格式 

string 	boolean	null 	undefined	number  symbol(es6新数据类型,定义独一无二的值或者属性,比如游戏名称id)

#### 3种引用数据类型

object  function  array

#### 11种内置对象

**global 	error 	Math 	RegExp	Date	string 	array 	number	object	function 	boolean **

#### 13种vue指令

**{{}}  	v-bind:	 v-on@	v-cloak v-text 	v-show(会渲染 display控制,频繁切换) 	v-if 	v-else-if	v-for	v-html 	v-pre 	v-once	v-model	 	  	**

#### 修饰符

**input 修饰符**    	

**trim** (去掉首尾空格) 	**lazy**(输入数据失去焦点后显示内容) 	**number**(先输入数字为数值	先输入字母就为字符串) 

**事件修饰符**

**once** (只触发一次事件)	**stop** (阻止事件冒泡)	**prevent**(阻止默认事件比如点击a标签不跳转页面.点击表单元素的提交按钮不会重新刷新页面) 	**self**(绑定触发事件为自己,避免冒泡) 	**capture**(捕捉冒泡  事件触发,若从外到里**有相同事件且该同类事件绑定了capture修饰符**,就直接先触发该事件,再去查找目标元素触发) 	passive (对DOM元素默认事件的性能优化,比如超出最大范围的滚动条滚动)	native  (将vue中组件转化为一个html标签,对html标签,没有多大用)



**事件触发的过程 : **

**首先:捕获阶段**  事件触发后从外到里,从document 开始依次向下查找触发 事件的元素 这个过程中经历各种元素成为捕捉

**其次:目标阶段**	找到目标元素后,触发目标元素绑定的事件

**最后:冒泡阶段**	从里到外,一层一层依次向上查找,若有相同事件,就直接触发



**监听方法 : **  addEventListener("click(事件名称)" , "事件触发后调用的函数" , "**默认false(冒泡传递,从里到外正常流程)**  true(捕捉传递,从外到里不寻常)")



#### ---vuex: 如何相互作用

state :储存状态值	 mutations:储存修改状态值的方法(同步的)  	actions:储存异步操作方法(异步请求)  ,提交的是mutations中的方法	modules:(当state状态值过多,需要分模板处理,每个模板都有state.actions ,getters,mutations)	getters(储存状态值的计算方法)

#### --vue

**model**:{data(){界面所需变量}    **methods**:{界面所用事件函数}}  	**watch**:每个变量的同名监听函数 	**computed**:{data中变量的计算属性}	**components**:{在一个组件中引入另一个组件①引入组件 ②挂载引入的组件,设置变量名 "v-child":child  ③将该组件添加到 模板中去 `<v-child></v-child>`}   **el**: 指向new Vue() 要监控的页面区域

#### ---路由传参

①router-link   router 中的地址信息path后 的 +name(地址值参数) 通过`$route.params.name`获取

②声明式  页面层`<router-link :to="{name:url ,params:{xx1:xx}}"> `  接收 	`$route.params.xx1`

③编程式  逻辑层` this.$router.push({path:url  ,query:{xx2:xx}})	`接收	`this.$route.query.xx2`

④命名式  逻辑层 `this.$router.push({name:名称地址 ,params:{xx3:xx}})`  	接收  `this.$route.params.xx3`

#### ---组件传参(vuex 及路由传参都是组件通信中的一种)

**父子传参** 

**props  :**  引入子组件  	在页面components中注册 	再通过 子组件标签的绑定事件传参 `<child :tochild="tochild"> </child>`	接收  :  `props:["tochild"] `-->页面可直接用

**$emit** : 监听事件中传参  事件触发-->`this.$emit(事件名 , 参数2)`  接收 `<child 事件名></child> ` -->事件名(参数2){xxx} 

-----

**$children** :直接获取   `this.$children[0].子组件中data中对象`

**$parent** :直接获取	`this.$parent[0].父组件中data中对象`

----

**兄弟传参** 	

**vuex**  : ()**具体如何实现 ? ? ? ? ? ? **

**隔代传参**

**provide** :定义的对象 (一般为一个对象或者函数) {xxx1}

接收: 逻辑层  inject:["xxx1"] --->页面可直接用(inject一般为一个字符串或者对象,无论嵌套的多深都可以获取到数据)

#### vue中的生命周期

**activated** 组件挂载后更新之前触发的钩子函数  (常用作keep live 的设定  被 keep-alive 缓存的组件激活时调用。 )

**创建**  beforeCreate Created   创建了 new Vue()实例对象,创建了data对象  以及data里面的属性  

 **挂载**  beforeMount  Mounted  使用new Vue() 及 data中的数据编译成真实DOM树 , 可以生成并操作虚拟DOM树 

**更新**  beforeUpdate  Updated	实时监控数据变化并更新DOM    

 **销毁**  beforeDestroy Destroyed	 组件实例销毁 (eg:v-if条件为false) 	手动调用 $destroy()方法销毁



### 

#### -路由生命周期里的钩子函数(6个)三个参数(to (即将要进入的路由对象).from(当前导航正要离开的路由对象), next(路由跳转执行的函数))

**全局守卫钩子**

**beforeEach** 	页面加载之前触发的函数 ,可用作登录状态判断,页面权限管理

**beforeAfter**	页面加载之后 的事件方法

**beforeEnter**	路由独享守卫(在路由配置信息中直接设置) 可用于缓存页面跳转,单个组件路由跳转事件操作

**组件内守卫钩子**

**beforeRouterEnter**  未加载组件实例 经常用作返回上一个组件页面

**beforeRouterUpdate** 	路由地址是动态变化的,当在两个组件返回跳转,组件被重用,就可以调用这个方法

**beforeRouterLeave**	离开组件页面时调用(用户修改页面内容未保存而退出,设置next(false)阻止页面跳转),以及清除页面定时器,防止占用内存,或者在关闭页面前将数据保存到webstorage以及vuex中

#### ---vue中自定义指令

vue.directive(id,[definition])  **id**是不带 **v-** 的名称(调用时 添加 **v-**)  **definition**是一个对象,对象里有一些不同生命周期阶段对应执行的不同函数 

也分为全局自定义指令(vue.directive(xx,xxx)) 和局部自定义指令 某个组件内里的与data /methods同级的 directives:{**指令名:{ 指令生命周期函数}**}

指令对象中的钩子函数:

**页面加载**或者**重新安装组件**时: 

 inserted (被绑定元素插入父元素时调用,父元素存在即可调用,不必存在document中)

 bind  (绑定元素时调用,用作初始化动作,只调用一次)

区别:调用bind时父节点为 null,调用 inserted 时父节点存在

**更新组件**时:

 update  (第一次是紧跟bind之后调用,获得的参数是绑定的初始值,之后被绑定元素所在的模板更新时调用,不论绑定值是否变化,通过比较前后的绑定值,可以忽略不必要的模板更新)

componentupdated(绑定元素的模板完成一次周期更新时调用) 

区别 :update  是在数据更新前, componentupdated 是在数据更新之后

**卸载组件**时:

unbind(解绑,只调用一次)

#### ---vue中的过滤器 filter(有点同数组中filter方法)

**可用在 {{xxx|过滤器名称}}**    **v-bind: src=" 'xxx'|过滤器名称"**  

全局过滤器: vue.filter(过滤器名称,fucntion(value){

​	return  value(处理)

})

单个组件过滤器 : filters("xxx",function(value){

​	return 	value+"!!!"

})

#### react组件通信https://www.jianshu.com/p/fb915d9c99c4

①父传子  props 中带参传入 

②子传父 props中 父传给子组件,子组件通过props中callback回调函数传参回父组件

③跨级组件 通信 useContext方式:先createContext 一个useContext对象,再在根组件中通过这个useContext对象的provider标签 通过value传参给根组件包裹的子组件,再在子组件中 使用useContext方法解构useContext对象中的参数 拿来使用

④非嵌套关系组件通信 引入events 依赖 通过eventElement对象来监听传值或者redux通信

#### 数组去重arr

① function x(xx){ return  Array.from(new set(xx))}  **(Array.from()是将类数组改为数组)**   

②[...new Set(arr)]

③  filter是循环数组值得出满足条件的一个新数组   var res= arr.filter(item,index,self){return self.indexOf(item)===index}

④for双层循环 **,内层的下标是外层下标加1**,内外层对比值,同值去掉后面一个,下标减一(这样才会继续从当前下标对应元素对比值)(原理是外层的一个值与内层里面每个值作比较,相同就祛除后面的一个值,下标减一并继续从原来位置比较)

⑤单层循环,设置一个空数组, arr循环,, 用 空数组的indexOf 查询每个值,全等于 -1 就添加进空数组 

#### function与箭头函数的差别

①写法上箭头函数简化

②this指向,箭头函数this指向一直不变,而function函数随调用的环境改变this指向会变

③函数声明提升 (function 声明的函数会函数提升(而var a=fucntion(){}不会提升),而箭头函数不会)

④构造函数(function声明函数可做构造函数使用,而箭头函数不能做构造函数)

#### ES5的数组家的方法

**map**	遍历,返回计算后的 新数组

**some**	遍历 短路逻辑  判断是否包含符合条件的**"某些"**元素 	返回 布尔值  

**every** 	遍历,短路逻辑	判断**所有元素**是否符合条件 有false就短路	返回布尔值

**filter** 	遍历 返回条件**筛选/计算**后的新数组	  

**reduce** 	(遍历 返回 array.reduce(function( **prev** , **cur**, **index**,  **arr** ){....}, **init初始值**)

其中，
 **arr** 表示原数组；
 **prev** 表示上一次调用回调时的返回值，或者初始值 init;
 **cur** 表示当前正在处理的数组元素；
 **index** 表示当前正在处理的数组元素的索引，若提供 init 值，则索引为0，否则索引为1；
 **init** 表示初始值。)



#### ---es6的继承

组合和继承是面向对象中两种代码复用的方式。

##### 1.组合定义

在新类里面创建原有类的对象，重复利用已有类的功能。(has-a关系)

##### 2.继承定义

可以使用现有类的功能，并且在无需重复编写原有类的情况下对原有类进行功能上的扩展。(is-a关系)

首先定义一个父类:  new Xxx1

① **原型链继承**     xx.prototype=new Xxx1  缺点:无法向父类构造函数传参,继承单一,所有新实例都会共享父类实例的属性.(但凡有一个实例改了原型属性,另一个实例也会被修改)

②**借用构造函数继承**   只继承构造函数的属性,不继承原型链上属性  bind call(可继承多个父类属性,call多个) apply   

③**组合继承**		组合原型链继承+借用构造函数继承  (子类函数  内部采用借用构造继承  外部采用原型链继承) 优点:完善了前面两种继承的单一继承性  缺点:连续两次调用构造函数,消耗内存

④**原型式继承** 	相当于将父类构造函数包装成一个参数,通过参数传递进入子类函数,在子类函数中生成一个新函数,新函数通过prototype属性赋值等于这个包装传入的参数  (缺点:无法复用)

⑤**寄生式继承**   	(相当于在原型式继承上套一层外壳),首先将原型式函数创建,其次将父类构造函数保存为一个对象,再 声明一个函数将原型式的函数包装成对象嵌入当前函数,再给这个包装的对象添加属性,相当于给原型式函数内部添加属性,然后返回该对象  最后将该声明的函数保存为一个对象, 进行属性调用, 所得到的就是经过父类构造函数返回的属性值

⑥**寄生组合式继承**

#### 原型链

**只有函数才有 prototype 属性   (prototype属性也是一个对象, 叫:原型对象)**

**函数也有 proto 属性 指向原型对象(prototype)**

**对象只有 proto属性指向原型对象 **

而在对象中使用 _ ___proto__ _ _ 属性一层一层向上查找某个属性时,(最后要么查到这个属性 , 要么 查到 object.prototype._ _ __proto__ _ _为null才截止) 这个查找过程形成的 proto 链就是原型链

****



#### undefined与 null 的区别

**undefined** 表示缺少值 , 应该有值而没有定义值,.(1变量被声明未赋值,2调用函数时该传参但是没有传,该参数为undefined,3 对象中,没有赋值 的属性,该属性值为undefined ,4函数没有返回值时,默认返回undefined)

**null** 表示没有对象,此处没有值  (1.作为函数的参数,表示该函数的参数不是对象  2.作为对象原型链的终点)

#### 内存泄漏 ????没写完

是指一块被分配的内存既不能使用,又不能回收,直到浏览器结束.  比如 1闭包外层函数中被引用的变量  /  2 字符串查看 length属性 ,因为字符串没有length属性  ,在函数做length时

#### 防抖+节流

**防抖**  	是指事件只有最后一次触发,才能执行完成	他是利用的 定时器 和清除定时器(clearTimerout(定时器名称) clearxxx(xxx))	若在事件执行过程中再次触发该事件,会调用清除定时器装置,并且重新刷新是时间执行该事件  (经常用于 **onresize** 窗口缩放事件  **onscroll** 滚动事件  **onmousemove** 鼠标移动事件)

**节流**		是指第一次 执行事件未完成就不能再第二次执行该事件  他是利用状态值来做的管理,比如状态值为true可以触发事件,点击发送请求后设置状态值为false 不能触发事件,直到获取到服务器响应返回结果才能吧状态值设置为true,才能再次触发事件   (经常用于点击事件,滚动事件)

#### 克隆

**浅拷贝(浅克隆)** 浅度拷贝（把数据的地址**赋值**给对应变量，而没有把具体的数据复制给变量，变量会随数据值的变化而变化）eg: var arr1=[xx, xxx,  xxxx]    var arr2=arr1   (arr2指向的地址与arr1一样)

**深拷贝(深克隆)**   (把数据赋值给对应的变量),而该变量指向的地址与源数据的地址互不相干,**深拷贝是拷贝的对象的各个层级的属性.**

​	**①**递归  (函数内部调用函数)	

function deepClone(obj){		

​	//首先var一个与参数同数据类型的空对象

​	var objClone=Array.isArray(obj) ? [] : {}

​	if(obj && typeof obj==="object"){	

​		//如果参数为对象类型就for..in循环

​		for(key in obj){

​			if(obj.hasOwnProperty(key)){

​				//如果这个参数子元素为对象就采用深拷贝

​				if(obj[key] && obj[key] ==="object"){

​						objClone(obj[key])=deepClone(obj[key])

​				}else{

​					//如果子元素不为引用类型数据就直接复制克隆
​					objClone(obj[key])=obj[key]

​				} 

​			}

​		}

​	}

}

​	**②** JSON .justify(xxx)  + JSON.parse(xxx) 	(有很多弊端, 比如时间戳会变成转化后的字符串 , , NaN会变为 null , 函数,undefined,infinity会丢失 ,如果转换对象中存在regExp 和error 则会成为空对象,还有只能克隆对象的自有属性,丢弃对象的constructor(构造函数),有循环的也不能克隆)解决: https://blog.csdn.net/u013565133/article/details/102819929 

var u=function (x){
    this.x=x
    alert(x)
}
var po=new u("kkk")
var a={
    name:"kk",
    age:18,
    aa:true,
    test:function(){alert("11")},
    kk:null,
    hh:undefined,
    cc:NaN,
    DD:-Infinity,
    ss:{
        naem:"ss",
        ss1:new RegExp(),
        ss2:new Error()
    },
    ffs:po,
    uy:Symbol("lk"),
    jk:[1,2,3,[4,5]]
    
}
var b=JSON.parse(JSON.stringify(a))
console.log(a,b)

​    **③**( https://www.cnblogs.com/dftencent/p/3666805.html ) jQuery中的 $.extend(true/fasle , 对象类型([] / {}) , 符合前面对象类型的对象从第一个到底n个 可选来作为参数,进行合并)  第一个参数为false就是浅拷贝 ,为true 就是深拷贝   (深拷贝在这里就体现在对象的深层次的属性合并,一般同名参数合并,后者会将前者覆盖, 浅拷贝会直接不会合并对象中对象里的属性,而深拷贝会)   



#### 事件委托(事件代理--冒泡原理) https://www.cnblogs.com/liugang-vip/p/5616484.html 

当用事件委托的时候，根本就不需要去遍历元素的子节点，只需要给父级元素添加事件就好了，其他的都是在js里面的执行，这样可以大大的减少dom操作，这才是事件委托的精髓所在。

事件委托可用于的事件  有 :  click  mouseup(松开鼠标左键) mousedown(按下鼠标左键) keyup keydown  keypress

不适合用的事件  mouseover(鼠标移出) mouseout(移入) mousemove(移动) 需要时刻计算元素位置 ,不好把控,其次blur focus 事件没有冒泡属性,就没有事件委托

当有不同**子元素**触发的事件不同时,根据其同级元素的共有特征(比如所有 **li** 的**id值**)来做关于 id值的 **switch+case**判断 ,这样就能在不同值时就能分别做不同的操作

当有**新子元素**添加 且要添加 后也需要带有 事件委托的方法, 就需要将 事件委托 的方法和 添加新元素的函数写成同一等级.

如果触发事件的子元素中包含多个嵌套关系的元素,如何确定触发事件的**初始元素** 究竟是绑定委托事件的父元素下的哪一个**子元素** 呢   ?(递归) 需要通过 监听事件+event.target 属性 +  while循环判断 ,最后找到该**事件触发的初始子元素** 执行对应事件,并且终止循环,且要将该事件对象赋值回 父元素对象



### -------说服点①----

#### promise  (新的优化异步操作的方法(以前是纯回调的形式-回调地狱)-----异步变同步)

**回调函数**:a函数作为参数放入b函数,a就是回调函数 , 在b 中使用 参数a ,就可以说a函数被b回调

**promise 是什么**:  语法上promise是一个构造函数 ,从功能上来说promise 对象用来封装了一个异步操作并且可以获得其结果

**promise状态改变** : 初始new 出来为 pending(未确定的) 状态  一种 是 pending 变为 resolved(成功解决) 值一般为value  另一种是 由 pending 变为 rejected(失败拒绝) 值一般为reason     **只有**这两种状态改变 ,且**只能改变一次**



——————

——————

#### 一些属性用法

**Object.definedProerty(obj , prop , descripter)**  用于直接在一个对象上定义一个新属性或者修改属性并且返回该对象

注意如果**call**和**apply**的第一个参数写的是**null**，那么**this**指向的是**window**对象 

vnode 是vue 编译的虚拟节点, oldVnode :上一次的虚拟节点,仅在update 和componentUpdated 钩子函数中可用



## 页面层

#### 定位 position  

 默认值 static 不定位,静态的处于正常流中 

relative (不脱离)    absolute (脱离 ,相对于已定位元素没有就是body)   fixed (脱离,相对于当前可视窗口)

#### 重排重绘与回流

**重排**: 页面的DOM节点发生改变, ,重新构建渲染树(只包含可见节点,不包含display:none元素)    (dom元素删除添加,.元素的位置,宽高 ,内容变化,或者页面渲染器初始化,浏览器窗口大小改变都会引发重排)	**(重排一定重绘 ,重绘不一定重排)**

**回流** :  构建渲染树时, 计算DOM节点在设备视口(viewport)内的确切位置和大小的阶段

**重绘** :  经过重排中的构建渲染树以及回流中的元素在视口确切位置及大小,就可将渲染树每个节点转换为屏幕的实际像素,这个过程叫重绘节点.

  

#### 不定宽div垂直水平居中

①**弹性**   display:flex    justify-content:center  +align-items:center

②**反转transform中 :**   translate( -50% , -50%)  **位移 +** **定位**  position:absolute   left:50%  top:50%

③**盒模型属性 **    display :**table-cell**     text-align:center   vertical-align:center

 ④**jQuery 居中 **   position:absolute  $(window).width - $(元素).outwidth/2  (窗口宽度减去元素外部宽度的一半) 

$(widow).height - $(元素).outheight/2 + $(document).scrollTop()  (窗口高度减去元素相对当前窗口中距离顶部高度的一半加上 剩余文档 滚动栏的高度)

#### 转换 

**deg  旋转度数rotate(ndeg)  从bottom 开始  大于0 是顺时针,小于0是逆时针** 



#### 样式

**隐藏占空间**visibility :hidden  opacity :0  (inherit属性,内部所有子元素都会继承样式变化)  

**隐藏不占空间**  display :none

**继承**   color 有继承  但 a标签不会继承 颜色值,必须指定在a标签样式上修改



#### ---css3动画实现

一般只需要设置  name(动画名称)  和 duration (持续时长)属性就行了  animate.css网站去引入想要的动画效果

①使用关键帧**自定义动画 :** **keyframes** {0% 样式~100%}  (样式有 transform(translate scale roate)转换 transition过渡)

②调用动画 animation ; name  duration  animation-timing-function delay

**css3新特性**  :transition(过渡)	animation(动画)  transform(转换)  boxshadow (阴影) 	 以及下面的选择器

#### ---CSS3新增选择器

**+ 是挨着符合前面且符合后面选择器的元素**

**~ 是除去第一个后面所有符合的该选择器的元素**

**:not(xxx)  / :nth-child(1+...)  / :first-child()  / :last-child()  /:only-child(唯一子女)  **	

#### h5的特性

 新增选择器 document.querySelector、document.querySelectorAll 

本地存储 localStorage 和 sessionStorage 

 媒体播放的 video 和 audio 

 绘画 canvas 

 跨域资源共享(CORS) Access-Control-Allow-Origin 

####  盒模型(border-sizing)

​	标准模型  :  content-box   (宽度为内容宽度+边框)

​	盒子模型(**IE家的**):   border-box  (宽度为边框和内边距加内容宽度)

#### **web攻击**(https://www.cnblogs.com/itsuibi/p/10752868.html)

①SQL注入 攻击 (在sql语句中where条件后面做一个永远为 true 的设置) 请求url中加一些参数(服务器无法识别而执行) (防御:做参数上传时做格式验证)

②xss (跨站脚本攻击)   在网页中输入框/url中或者向页面注入脚本(js,html代码片段)  达到盗用cookie或者植入广告等  (防御:①过滤:移除用户输入内容中的一些script节点iframe节点等②编码 使用encode将一些危险字节转化成字符串)

③csrf (跨站伪装请求)  获取A网站cookie信息,在不等出A的情况下用A的cookie 请求B有病毒网页,从而获取用户权限做一些危险操作  (防御:做token验证,服务器端先发一个token,客户端做表单提交时先验证token再执行下一步)

**xss与csrf的区别: xss无需获取cookie等信息,而csrf需要**



#### 前端优化 (性能优化) https://www.cnblogs.com/lanxiansen/p/10972802.html 

①减少操作DOM的次数  ,能够用css样式解决的就不用js 程序去做(因为每个函数都是一个对象,对象会占内存,影响性能),  事件委托处理减少DOM操作,添加元素能一次添加多个就添加多个,

②减少请求次数,雪碧图精灵图(将多个图标存在一张图上)

#### ajax原生

①创建异步对象 var  xhr=  new XMLHttpRequest();

②创建请求对象 	xhr.open("请求方式(get/post)","请求的url +参数" ,是否采用异步加载 : true )

③发送请求  xhr.send()

④ 设置监接收响应	xhr.onreadystatechange=function (){

​	if(xhr.readyState==4 && xhr.status==200){

​		 var  xx=xhr.responseText;

​	}

}

(状态值变化四次,第一次是打开连接请求正发送 ,接收响应头信息,接收响应主体,响应数据接收完毕)

#### jQuery发送请求

 $.ajax({

  	url:"服务器端接口地址",
  	
  	type:"get或post",
  	
  	data:{ 参数名: 参数值, ... },
  	
  	dataType:"json",
  	
  	success:function(result){
  	
  		//result就是服务器端返回的结果
  	
  		//**不用自己调** JSON.parse() 
  	
  	}

 })

#### 微信前面的那些记录的知识点



keep-alive  (保存组件数据状态,避免组件重复渲染) 实现及原理

实现keep-alive缓存:

 **一般方法**在 app.vue里设置包裹`<router-view/>  ` 标签缓存全部组件, 然后需要单独缓存就得 在 每个组件的配置信息里的路由元(meta属性)中设置一段字段(keep-alive:true/false)取布尔值,再在 app.vue中 router-view标签设置 v-if="$route.meta.keepAlive"判断从而来缓存不同标签, 或者 根据 每个组件的name 属性来 设置 keep-alive组件中的 include="组件name名"(缓存当前组件) exclude="组件name名"(缓存除当前组件外的其他组件)   两个属性都可以用逗号分隔字符串、正则表达式或一个数组来表示： ,在 https://cn.vuejs.org/v2/api/#keep-alive    https://blog.csdn.net/weixin_44369568/article/details/90727668 

**高阶的方法: **动态组件设置 `<component :is="xx"></component> `  看案例

**vue里的  三个不常用的生命周期钩子** 

**只有**被kepp-alive包裹的缓存组件中会多出activated 和deactivated两个生命周期钩子

**activated** ( 被 keep-alive 缓存的组件激活时调用。 )

**deactivated**( 被 keep-alive 缓存的组件停用时调用。 )  

**errorCaptured** ( 当捕获一个来自子孙组件的错误时被调用。 )周期

 **注意：使用了keep-alive就不会调用beforeDestroy(组件销毁前钩子)和destroyed(组件销毁)，因为组件没被销毁，被缓存起来了。** 

——————

——————

面试点:

**深度监听**



**vue 双向绑定原理 手写 **    get set



**你封装过什么组件** (全局组件???)





虚拟dom 树 diff算法  (diff算法就是虚拟dom节点和dom节点之间同层级之间的比较。有差异就通过vue中封装的增删改查操作改变，没有的话，就不做任何操作。我是这么理解的)



同步变异步 (async await (好像是promise 的升级, es7简化了then操作))  ,异步请求的过程 



hook监听生命周期



bind 的封装

--------------------------------------------

**video 几个属性 (自动播放 循环播放)   aduio音频属性 **

 (视频标签还有个海报帧属性 poster :url )	autoplay:true是否自动播放 	loop是否循环播放 	muted 是否静音 	preload预载入	

**obj="abcdefg"能用reverse或者 不能用reverse 翻转的方法**
使用reverse:  obj.split('').reverse().join('')
不使用reverse很多种:  

①let x=obj.split('')  +let o=[ ]  => while(x.length){ o.push(x.pop()) }  => o.join('')
②unshift +for 循环中    c.unshift( obj[i]) => c.join('')

③ let x=obj.split('') +let o=[ ]  =>while(x.length){ o.unshift(x.shift()) } => o.join('')

④ let x=obj.split('') +let o=[ ]  => while(x.length) { o.push(x.splice(x.length-1,1)[0] ) } => o.join('')



搞清楚下 前后端这个接口如何弄的



宏任务和微任务具体在实际项目中哪里体现,结合记忆

**history 和hash两种模式有什么区别(好像有问)?** 



 **attr和prop的区别 ?**

**prop()函数的结果:**

   1.如果有相应的属性，返回指定属性值。

   2.如果没有相应的属性，返回值是空字符串。

**attr()函数的结果:**

   1.如果有相应的属性，返回指定属性值。

   2.如果没有相应的属性，返回值是undefined。

对于HTML元素本身就带有的固有属性，在处理时，使用prop方法。

对于HTML元素我们自己自定义的DOM属性，在处理时，使用attr方法。

具有 true 和 false 两个属性的属性，如 checked, selected 或者 disabled 使用prop()



**promise 写一个函数** 以及promise函数什么可以一直  .then ()   :  返回promise对象的时候可以无限.then()下去  =>方法:先 var变量保存promise实例, 并返回promise实例对象, 外层函数包裹住这个实例 ,调用外层函数,并在 .then ()中返回下一个 promise实例对象 ,这样方能一直 .then

promise简单结构

new Promise((resolve ,reject)=>{	

​	console.log("我要一直then下去")

​	resolve(42);

}).then(res=>{

​	console.log(res)  //42

})   

**什么是token**

Token是服务端生成的一串字符串，以作客户端进行请求的一个令牌，当第一次登录后，服务器生成一个Token便将此Token返回给客户端，以后客户端只需带上这个Token前来请求数据即可，无需再次带上用户名和密码。

 使用Token的目的：Token的目的是为了减轻服务器的压力，减少频繁的查询数据库，使服务器更加健壮。 ( 1、用设备号/设备mac地址作为Token（推荐）  2、用session值作为Token )

**编写mysql数据库的方式有两种    引入  mock**  拦截请求,设置返回数据

自我介绍和前公司离职理由(禅道)

放大镜加入项目

看下react的笔记 以及三大框架的简单区别

**bilibili学习**

webpark 打包黑马 [https://search.bilibili.com/all?keyword=%E5%89%8D%E7%AB%AFwebpack](https://search.bilibili.com/all?keyword=前端webpack) 
 https://space.bilibili.com/14608003/article   https://www.bilibili.com/video/BV1vE411871g?from=search&seid=18256844586902495183 

promise 讲解 (尚硅谷) https://www.bilibili.com/video/BV1MJ41197Eu?p=9 

vuex打造购物车 https://www.bilibili.com/video/BV1Jx411Z7Nt?from=search&seid=17925279686531896253 

微信支付(可以多找两个)  https://www.bilibili.com/video/BV1ps411c7Lg?p=7    https://pay.weixin.qq.com/wiki/doc/api/index.html 



### 等会回来把他们说的点弄一下,明上午具体复习简历,简要查漏复习

**数组最大值 :**  a.sort() => a[a.length-1]   设最大值循环对比得出

![img](G:\qq3C9DDBF4899E2CC691EF66E1B1154C96\39be90c714a54e16bf3bffb190e8b7ef\1602427907205.png)

**http** 超文本传输协议 (明文传输数据)

 HTTP是一个基于TCP/IP通信协议来传递数据 

 1、简单快速：客户向服务器请求服务时，只需传送请求方法和路径。请求方法常用的有GET、HEAD、POST。每种方法规定了客户与服务器联系的类型不同 

 2、灵活：HTTP允许传输任意类型的数据对象。 

 3.无连接：无连接的含义是限制每次连接只处理一个请求。服务器处理完客户的请求，并收到客户的应答后，即断开连接。采用这种方式可以节省传输时间。 

 4.无状态：HTTP协议是无状态协议。无状态是指协议对于事务处理没有记忆能力 

**mvc**  是一种很典型的组织代码的三层思维框架, 它使应用程序中的输入/处理/输出三者分开,主分为model 模型层view视图层 controller控制层 ,流程一般为通过视图层发送请求,控制层接收数据,然后在模型层中做一个判断后调用对应的逻辑数据.

**进程和线程**

进程是系统中正在运行的一个程序,是系统资源分配下的一个独立实体,拥有独立的地址空间,

,而线程则是进程中的 一个实体, 是进程的一条执行路径.一个进程中可以拥有多条线程

如何选择二者 ,需要稳定安全选进程,需要速度时选线程(大量计算频繁切换选线程)

**overload（重载）和 override（重写） **：

重载:

Overload是重载的意思。它是指我们可以定义一些名称相同的方法，通过定义不同的输入参数来区分这些方法，然后在调用时，虚拟机就会根据不同的参数样式，来选择合适的方法执行。

重载表示同一个类中可以有多个名称相同的方法，但这些方法的参数列表各不相同（即参数个数或类型不同）。方法名相同:1.参数类型、个数、顺序至少一种不相同。

Override是覆盖的意思，也就是重写。从字面意思可以知道，它是覆盖了一个方法并且对其重写，以求达到不同的作用。

重写表示子类中的方法可以与父类（或接口）中的某个方法的名称和参数完全相同。

重写:方法名,不同 返回值和形参都不能改变。**即外壳不变，核心重写！** 

 重写的好处在于子类可以根据需要，定义特定于自己的行为。 也就是说子类能够根据需要实现父类的方法 

**类和对象的区别**

所谓“类”就是对象的模板，对象就是“类”的实例,JavaScript语言没有“类”，而改用构造函数（constructor）作为对象的模板。所谓“构造函数”，就是专门用来生成“对象”的函数。它提供模板，作为对象的基本结构。一个构造函数，可以生成多个对象，这些对象都有相同的结构。 

**oop** 面向对象程序设计  是一种计算机编程架构 

 OOP思想中很重要的有五点，类，对象，还有面向对象的三大特征：继承，多态和封装。 

 OOP达到了软件工程的三个主要目标：重用性、灵活性和扩展性。 



**class修饰符** https://www.runoob.com/java/java-modifier-types.html 

###### 访问控制修饰符 默认default 公有public  私有private 受保护的protected



**ts 中 abstract  class 跟interface的区别**

抽象类(abstract)

含有abstract修饰符的class即为抽象类，abstract 类不能创建的实例对象。

含有abstract方法的类必须定义为abstract class，abstract class类中的方法不必是抽象的。

接口（interface）

interface 可以说成是抽象类的一种特例，接口中的所有方法都必须是抽象的。

区别:

1.抽象类可以有构造方法，接口中不能有构造方法。

2.抽象类中可以有普通成员变量，接口中没有普通成员变量

3.抽象类中可以包含非抽象的普通方法，接口中的所有方法必须都是抽象的，不能有非抽象的普通方法

4.抽象类中可以包含静态方法，接口中不能包含静态方法 

5.一个类可以实现多个接口，但只能继承一个抽象类。 

**java**:

类：事物的描述。是具备某些共同特征的实体的集合，它是一种抽象的数据类型，它是对所具有相同特征实体的抽象。在面向对象的程序设计语言中，类是对一类“事物”的属性与行为的抽象。

对象：该类事物的实例。在Java中通过new进行创建。是一个真实世界中的实体，对象与实体是一一对应关系的，意思就是现实世界的每一个实体都是一个对象，所以对象是一个具体的概念。对象是一种个性的表示，表示一个独立的个体，每个对象拥有自己独立的属性，依靠属性来区分不同对象。
　　1，类是一个抽象的概念，它不存在于现实中的时间/空间里，类只是为所有的对象定义了抽象的属性与行为。就好像“Person（人）”这个类，它虽然可以包含很多个体，但它本身不存在于现实世界上。
　　2，对象是类的一个具体。它是一个实实在在存在的东西。
　　3，类是一个静态的概念，类本身不携带任何数据。当没有为类创建任何对象时，类本身不存在于内存空间中。
　　4，对象是一个动态的概念。每一个对象都存在着有别于其它对象的属于自己的独特的属性和行为。对象的属性可以随着它自己的行为而发生改变。

具体的：**类是对象的模板，对象是类的实例。类只有通过对象才可以使用，而在开发之中应该先产生类，之后再产生对象。类不能直接使用，对象是可以直接使用的。**

****

var url="http://www.taobao.com/index.php?keya=00&keyb=11&keyc=22";
function parseQueryString(url){
      var str=url.split("?")[1];
       var iterms = str.split("&");
       var arr,Json={};
       for(var i=0;i<iterms.length;i++){
               arr=iterms[i].split("=");
               Json[arr[0]]=arr[1];
       }
       return Json;
}

var obj= parseQueryString(url);
console.log(obj)

function parse(url){

​	var a=url.split("?")[1];

​	var b=a.split("&");
​	var c={}

​	for(var i=0;i<b.length; i++){

​		c[b[i].split("=")[0]]=b[i].split("=")[1]

​	}

​	return c;

}

console.log(parse(url))

****

### 自然研究院

**数据库常用语句**

select 语句复杂查询 ****

 以下假设表名为A
一、SQL Server
解法一：
select top 10 * from A where ID not in (select top 30 ID from A)
解法二：
select top 10 * from (select top 40 ID from A order by ID) as a order by [a.ID](http://a.id/) desc
解法三：
select * from(select *,ROW_NUMBER() over(order by ID)as ‘userID’ from A) as a where a.userID between 31 and 40
二、MYSQL
select * from A where limit 31,10
三、Oracle
select * from A where rownum <=40  and rownum>31

**递归斐波那契数列代码**求第n位值

**递归解法?????**:function F(n){

​		if(n==1||n==2){

​			return 1

​		}else{

​			return  F(n)=F(n-1)+F(n-2)

​		}

}

优化循环解法: function f(n){

​		let n1=1,n2=1

​		if(n==1||n==2){

​			return 1

​		}

​		for(var i=3;i<n;i++){

​			var c=n1;

​			n1=n2;	//用 c 做个中间量,这样就能腾出n1来接收n2的值

​			n2=c+n2

​		}

​		return	n2;

}





**三大框架的认识**



**int数组由大到小排序 数组api运用**

obj.sort((a,b)=>{return a-b})

**$ajax原生以及 jQuery封装**

$.ajax({

​	url:"接口url",

​	type:"get/post/",

​	data:{参数名:"参数值"},

​	datatype:"json/jsonp",

​	success:function (res){

​		console.log(res)

​	}	

})

原生ajax:

创建异步对象:var xhr=new XMLHttpRequest();

打开连接,创建请求  xhr.open("get/post","url+参数","true")

发送请求: xhr.send()

创建监听,接收响应 xhr.onreadystatechange=function (){

​	if(xhr.onreadystate==4 && xhr.status==200){

​		var  x=xhr.responseText

​	}

}



****

### uniapp



****

#### 查询一个字符串或数组中某个元素/字符出现几次

##### ①循环套对象形式



var a=function (obj){

​	var/const x={}

​	for (var/let i=0;i<obj.length;i++){

​		var/const o=obj[i]

​		if(x[o]===undefined)或者if(!x[o]){

​				x[o]=0//判断对象中是否有这个属性,没有就添加并且添加属性值为数值0
​		}

​		x[o]++ //如果该属性已存在则每次出现的次数直接自增

​	}

​	return x

}

console.log(a("adddaaa" / [5,4,12,4,5,4,2,3]))

##### ②reduce()方法

var obj=[4,2,1,5,4,2,5]

var a=obj.reduce((pre,cur)=>{

​				if(cur in pre){

​						pre[cur]++

​				}else{

​						pre[cur]=1

​				}

​				return pre

​		},**{}**)

console.log(a)



##### 焦哥剩下记录没搞定

##### 

CSS选择器以及权重这些基础  important 1000+ 内联1000 	id选择器100 类伪类10 元素 1 通用0 继承无 

JS基础



### 以及其他的总结word文档----(放百度云,防止电脑坏掉)

### 如何提高自己的逻辑运算能力?

多做算法题?



-----------------



****

#### 确定生活的目标:

 **注重皮肤管理外表形象**

**记背**--> 尚硅谷课程promise9基本使用--> 东哥jsonp 的vue使用 --> 放大镜 -->老陈的题

把常识题看下,比如前端如何接口调试,三大框架区别

 2025年前计划买房=>户口 =>地区(三室100平以内 120万) =>预判收入(主业用心发展继续深耕人脉,资源,机会,.并开展第二副业比如扩展自己的源能力(沟通表达,其他技能突破,多向牛人学习并有自己的独到思维能力))

****

#### 自我介绍

个人信息=> 求职岗位 => 上个工作经历 => 因为上个工作了解到前端 =>学的不是很多,需要系统性学习 => 个人特点 =>最后希望能够加入到贵公司 =>谢谢~

****

### 面试关键点:

##### 1.有限时间内,充分自信地自我介绍

##### 2.抓住任何一个全方面表现自己的机会(比如不合场合的现场跳舞,以及通过观察现场细节来结合表达自己的话术,细节)

##### 3.坦诚地面对问题,进行真实地表述

##### 5.先有付出,才会有收获(先说自己能给企业带来什么,再谈薪资)



****

