你好，很高兴向你介绍我自己

hello ，	It's really a great honey to have this opportunity for a interview. Now I will introduce myself briefly.
My name is Liukai. Engaged in program development for three years,currently doing related business in a bank.
The project team is divided into several groups，and I am the group leader. I am responsible for project component
encapsulation ，publish online ，and version management. I am familiar with reactJs and can write vueJs.

In my spare time，I enjoy running ，swimming ，and learning more programming skills. 

I think I earned and learned more interpersonal and technical skills from the working experience.

So it's the time to seek a bigger and more challenging flatform.

Gain more opportunities to show myself value and learn more.

~~I think I'm a good team player,and I'm a person of great honesty to others.~~

~~Also I am able to work under great perssure.~~

That's all,thank you so much.



answer：

#### let var const 三者区别：

let 不能多次声明同一个变量，不存在声明提升，受块级作用域调用限制
var 可以多次声明同一变量，第二次声明的值会把前一次声明的值覆盖，存在声明提升，可先声明后调用，但值不能提升，不受块级作用域调用限制
const 不能多次声明同一变量且声明时需要初始化（初始赋值），常用作声明一个常量且声明的常量不可改变，不存在声明提升，受块级作用域调用限制
【扩展:const 声明的对象,其变量指向的地址值不会改变,但可以更改其内部属性的值】

```js
const obj={kk:'lk',aa:455}
const obj2='sss'
obj.aa=obj2
let obj3=obj 
console.log(obj,obj3===obj)//{kk: 'lk', aa: 'sss'} true
obj3.aa=666
console.log(obj,obj3===obj)//{kk: 'lk', aa: 666}  true
```



#### 缓存（储存量大小，储存使用场景不同）：

cookie 内部缓存：常用作用户信息储存，储存大小在4kb左右，储存格式为键值对，可通过path设置储存路径，通过expires设置储存时间
webstorage：（localstorage，sessionstorage）界面缓存
sessionstorage：常用作绘画储存，储存大小在1mb左右，常常会话结束关闭当前页面时清除缓存
localstorage：本地永久缓存，储存大小随设备不同而不一致，一般在2.5-10mb之间，可通过调用clean或者removeItem清除，其次当localstorage缓存过大时，
会占据浏览器缓存空间，造成页面卡顿现象

#### ES5->ES6->ES7 :

es5 中map和forEach的区别： ①map比foreach 的效率高 ②map有返回值，可做链式操作，而foreach没有返回值无法做链式操作③使用场景不同，map
常用作有返回新的值的场景，而foreach常用作读取数组数据单纯执行逻辑的场景【扩展:es5中还有for /for in循环】

es6 ①相对于es5有块级作用域 ②模板字符串拼接变量③扩展运算符(...)浅拷贝数组【扩展：深拷贝**JSON.parse（JSON.stringify）**有问题，比如undefined拷贝后为null，null为NaN,function为空,date对象为时间字符串, 深拷贝还有Object.assign({},{}) 如果对象中属性值无引用数据类型就是深拷贝,否则就是浅拷贝】
④解构运算符（{}）常用作数组以及对象的直接解构取值和赋值
⑤箭头函数【扩展：function函数和箭头函数的区别：小①：function声明函数存在生命提升，可先调用后声明，箭头函数不能声明提升
 小②：function函数的this指向随着函数调用环境的改变而改变，而箭头函数this指向不会改变 小③：function函数可做new构造函数，而箭头函数不行】
⑥symbol 数据类型 常用作全局唯一量,比如个人ID账号，【扩展：数据类型：基础数据类型：String Number Boolean Null Undefined symbol 
 引用数据类型： Function Object Date Array RegExp(正则),检测数据类型方法:① typeof(xxx) ②instanceof 和constructor (多用于引用数据类型检测) 

```js
eg: let arr=['1','2'] console.log(arr instanceof Array)//true
console.log(arr.constructor===Array)//true
```

③Object.protype.toString.call(xxx) ④ jQuery中 $.type(xxx)】
⑦class 类 构造函数 

```js
class XXX{
    constructor(sss){
        this.x=sss;
        this.y=sss+1;
    } 
    xxx(){console.log(this.x+this.y) } 
    yyy(){} 
} 
var fun=new XXX('555') 
console.log(fun.x，fun.y) 
```





es7 async await ：就是promise 去掉 .then 的一个拆分写法 ，async 可以发起等待，而不用写await接收等待 ，但是在node环境不能没有发起等待就直接
写await接收等待  ，而在浏览器控制台环境 可以单独写await发起等待

======

#### react和vue 的区别：

相同:①从框架层来说都是采用数据驱动视图的构造原理,开发时只需要注意数据层的变化就行
②都是单向数据流的传递方式,且页面展现都是采用单页面切换不同组件的方式展现
③都采用虚拟DOM的方式来计算dom节点,更新dom树,渲染页面
不同点:①react采用jsx语法,就html和css全写入js中,all in js,而vue沿用原生html的方式将html/css/js分为三大模块放入template模板中分模块管理,而vue也支持jsx语法
②react他没有太多的option api,类组件中有完整的生命周期函数,而函数组件中有hook钩子函数完善,而vue 则是将常见的操作比如循环,ifelse判断双向绑定等封装成option api调用,节省了代码
③最大的不同是两者的dom diff算法不同,两者都是采用同层级节点比较,但react 采用单层遍历dom树节点,从左往右遍历,根据新旧dom树的index不同来判断当前dom节点是删除还是添加或者修改
而vue采用双层遍历dom树节点的方式,从两端向中间对比,有四种对比方式,分别为新旧dom树的头部与头部
尾部与尾部,新旧节点树的头部与尾部,新旧树的尾部与头部,而这样对比的速度更快,只需要遍历完新或旧dom树一层就行了, 其次:再处理对比不同结果时处理方案不同比如一个节点的类型相同属性不同,vue是删除新建,而react是修改节点以及当一个集合最后一个节点需要移动到第一个节点时,react是将前面所有节点后移,而vue则是直接调换前后节点,所以vue相对react来说diff算法更节省性能开销

#### react生命周期(组件的挂载/更新/卸载)

初始时经历:getinitalState (初始化state)以及getDefaultprops(设置默认的props)
组件挂载:componentwillmonunt(dom还未生成可修改state) render初次解析渲染 componentDidmonunt(dom生成完成,可操作dom)
组件更新:shouldcomponentUpdate(可以控制组件是否更新渲染,节省组件渲染性能开销,默认返回true)
componentWillupdate(组件初始更新)render(第二次解析渲染)componentDidUpdate(组件更新完成)
组件卸载:componentWillunmonunt(组件卸载可以清除周期定时器(clearInterval)以及清除缓存)

#### react组件通信:(四类:父子组件,父传子,子传父,多层级嵌套组件间通信,非嵌套型组件间通信)

父子:无论类组件还是函数组件都可通过props传递参数,其次可在父组件设定callback函数,使子组件传递对应参数给父组件
类组件还可以通过路由传参,将参数添加到props路由对象中,跳转路由传递
多层级嵌套组件通信:常用的是函数hook基础钩子useContext ,原理是在根组件设定 context对象,通过
provider标签的value属性传递参数,再在深层级组件中使用useContext方法获取参数
非嵌套性组件通信:两种方案:一种引入第三方npm表events,一个组件中设定监听函数milier,设置type类型
以及对应参数,再在另一组件中调用这个监听函数,传入对应type类型获取参数
第二种使用react-redux :各个组件共用一个state状态中心,相互都可设置和取用对应的参数

#### react函数组件和类组件的区别：

相同点:两种组件都是采用props传参,拿值,执行逻辑,render里return出一个react元素,渲染页面的纯函数式组件
不同点:class类组件有完整的生命周期以及组件内部的state状态管理机制,而函数组件本身就是一个js函数执行完逻辑然后return,它更多的功能是取用props渲染的一个UI组件,也没有this无需实例化,相比于类组件有this需要组件实例来说渲染性能开销更少,其次函数组件也借用hook钩子实现组件内部的变量设定以及初始化函数和监测变量变化的函数逻辑

#### react-redux:

redux本身是一个状态管理库,没有mbox更高效,它自身有getstate/dispatch/subscribe等方法,他可以用于任何前端
框架
而react是单项数据流的方式,数据回溯能力差,就算写callback函数使数据回传也不能保证各个组件间共同通信时数
据的即时反馈效应,而在类组件中通过组件内部的state状态管理可以想到的一种解决方案是将state提升到各个组件的最顶部,使state成为各个组件通用的状态中心,而这个state提升上来就是react-redux中的store,而这个store是通过reducer来创立的,reducer主要用于设定初始的state状态值以及接收dispatch函数分类处理生成新的state提供给store分发给其他组件,而reducer也可以有多个,可通过combinereducers来融合为一个reducer.
其次各组件通过react-redux中connect这个科里化函数来实现与store的链接,connect的作用首先是对组件做一个加
强,其次通过其内部的参数(mapstateToprops以及mapDispatchToprops)把组件分为UI组件和容器组件,UI组件单纯是
取用state来渲染组件,而容器组件除了渲染UI以外还有发送dispatch函数的事件来更新state的功能

#### 函数hook钩子运用:(分三类:基础钩子/附加钩子/自定义钩子)

基础钩子:useState useEffect useContext
附加钩子(通常都是优化组件渲染性能的):useRef:可以定义变量,且变量变化不会引起组件重新渲染,比如分页页码,还可以在dom节点定义ref属性,通过.current来获取该dom元素
useMemo:常用作缓存一个值,比如父组件定义某个值传给子组件,而这个值改变会引发子组件重新渲染,而用useMemo
在父组件中来定义这个值,当父组件重新渲染时,只要这个使用useMemo缓存的值没变化子组件就能不重新渲染
【扩展:memo常常用来包裹只传值的子组件(当前子组件未传递函数参数),作用是当父组件重渲染且传递给子组件的值未改变时,子组件中没有任何变化时,那父组件的重渲染不会引发子组件的重渲染】
useCallback:常用作缓存一个函数,如父组件定义一个回调函数传递给子组件,这个回调函数被usecallback缓存起来,当前子组件调用该函数,使父组件重渲染,而子组件因为使用usecallback缓存当前函数则不会改变函数储存地址,就
不会跟随父组件重渲染

记住:useMemo以及useCallback第一个参数为一个函数,第二参数为监测的依赖项,依赖项改变就会执行第一个函数参数,若依赖项为空数组则永远不会执行函数参数逻辑

#### react的优缺点

优点:①:使用虚拟DOM计算dom节点更新渲染组件
【扩展:虚拟 virtual dom就是一个dom树的对象,它包含当前dom节点的标签名,标签属性(calssname,key..),事件,子元素等等,虚拟DOM的优点:小①:减少dom操作次数(添加100个元素,原生dom添加100次,虚拟dom合并为一个元素,添加1次,以及通过dom diff算法算出添加100元素,可能只有几个是新元素只需添加几次)小②:跨平台渲染能力强,虚拟dom本身是一个js对象,可以是一个小程序对象或者一个ios一个安卓一个pc端对象) 缺点:需要创建额外函数,比如
createElement函数h函数,但react采用babel来转译简化,而vue依赖vue-loader来转译简化h函数】
②:组件采用高度封装的模式编程,可以将很多重复的代码写入一个组件块中,能够提高代码的复用性和可维护性
③:react没有太多的option api调用,类组件有完整的生命函数,函数组件也有hook钩子函数做完善,对js基础不错的
上手难度低
缺点:①不能用作单一的框架使用,一般配合react-redux,react-router等三方库的产品完善框架来使用
②组件代码高度封装,对一些涉及dom底层的操作完全限制,对原生编程环境不太友好
③数据单向流通,数据回溯能力比较差,做表单类的组件比较麻烦
④当项目过大,运行的包过多,对电脑性能要求高且跑一次项目很费时间

#### tcp协议的几次握手

##### 连接:三次握手

第一次握手:客户端向服务器发起连接请求(SYN=1)以及发送序号(Seq=x)
第二次握手:服务器接收连接,确认序号(Seq)有效(ACK),向客户端发送同意连接请求(SYN=1),发起序号(Seq=y)以及
确认号(Ack=x+1)[确认方Ack号=发起方Seq序号+1]
第三次握手:客户端接收服务器端确认数据的tcp报文后,发送最后一段确认服务器端的同意连接请求的tcp报文,
发送ACK确认标志,确认号Ack=y+1,序号Seq=x+1(等于服务器端发送的确认号)
最后服务端收到客户端确认收到服务端发送的确认连接报文,结束握手
为什么要三次握手?
因为第二次可以防止客户端无端请求无效地址,浪费服务器资源开销,其次服务器确认信号存在延迟,所以必须向客户端发送确认建立的信号,而且没有第三次握手服务器端是不知道客户端是否接收到建立连接的信息的

##### 断开链接:四次挥手

第一次:客户端发送断开连接请求,第二次:服务器端返回确认断开连接信号(但无法及时断开连接) 第三次:服务器端处理好断开连接的数据的准备,发送确认断开连接的报文 第四次:客户端接收服务器端发送的准备断开连接的报文,断开连接并发送报文,  然后服务器端收到报文,关闭当前与客户端的连接
为什么要四次挥手?
因为从服务器端接收客户端的断开连接请求时(不能及时断开连接)只能立即返回确认断开连接的信号,而真正断开连接还需要一段时间去处理,而处理完发送第三次挥手表示服务器端做好断开连接的准备,然后第四次客户端确认断开
连接,服务器接收后断开连接

#### 浏览器 输入url到渲染页面的过程:

第一步寻找IP地址,首先在浏览器缓存查找有没有这个域名的ip地址,其次在host文件中查找有没有配置这个域名的ip地址,再到路由器的缓存里查找,再到dns服务器查找以及更高的dns服务查找,直到找到
第二步就是请求数据.向ip地址发起连接请求,进行tcp协议的交涉,三次握手,连接建立成功后服务器就返回对应的数据,然后进行tcp断开连接的四次挥手
第三步页面展现,解析html文件创建dom树.解析css文件形成css对象模型,将css和dom合并构建渲染树,最后布局和
绘制渲染树,生成页面



#### 高阶函数:

定义: 函数的参数为函数或者函数的返回值为一个函数

常见的高阶函数: 数组api (map,filter )以及react-redux中的connect 函数

用高阶函数 的好处/优点:



#### webpack

主要由四个部分组成:分别是 entry(入口文件) / output(出口文件) / loader(调和器) /plugin(插件)

 **loader(调和器):** 常见调和器: css-loader/style-loader/sass-loader/less-loader /url-loader/babel-loader(JS解析调和器)/postcss-loader(适应各个浏览器的css适配调和器)

**plugin(插件)**: 常见插件 有热加载插件 ,html文件解析插件 htm-webpack-plugin ,压缩插件 gzip

##### react本身 自带 sass 样式预加载语言, 如果要配置less 的话 需要在webpack.config.js中去配置仿照sass 的案例复制一套属于less 的写法配置

##### react+umi 记住umi自身封装了 less语言 以及webpack配置,只能单独按着umi官方配置说明配置对应的webpack插件

![preview](https://pic3.zhimg.com/v2-c1b51567c34b678f02088708a7b91a52_r.jpg)